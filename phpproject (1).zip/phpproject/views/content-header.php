<header id="header">
        <nav class="navbar navbar-fixed-top" role="banner">
            <div class="container">
                <div class="navbar-header">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    
                    
                    
                    
                    <?php if($LogoLink == 1) {?>
					<a class="navbar-brand" href="<?php echo $LogoUrl;?>">
					<?php if($LogoType == 'text'){echo $LogoText; } else { ?>
                    <img src="<?php echo $LogoImage; ?>" /><?php }?>
                    </a>
                    <?php } else { 
					if($LogoType == 'text'){echo $LogoText; } else { ?>
					<img src="<?php echo $LogoImage; ?>" /><?php
					}}?>
                    
                    
                </div>				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
                    <!--class="active"-->
                    <?php foreach($PlatTopMenus as $MenuItem) { ?>
                        <li><a href="<?php if($MenuItem['menu_link_type'] == 'internal') { echo
						$MenuItem['menu_internal_url']; } else { echo $MenuItem['menu_external_url']; } ?>" target="<?php echo
						$MenuItem['menutarget']; ?>"><?php echo $MenuItem['menu_title']; ?> </a>
                        <?php if (isset($MenuItem['children'])) { ?>
                        <ul>
                        <?php foreach ($MenuItem['children'] as $MenuSubItem) {?><li><a href="<?php if (
						$MenuSubItem['menu_link_type'] == 'internal') { echo $MenuSubItem['menu_internal_url']; } else {echo
						$MenuSubItem['menu_external_url'];} ?>" target="<?php echo $MenuSubItem['menu_target']; ?>"><?php echo 
						$MenuSubItem['menu_title']; ?></a></li>
                        <?php } ?>
                        </ul>
                        <?php } ?>
                        </li>
                        <?php } ?>                                        
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->		
    </header><!--/header-->	
    
    
    