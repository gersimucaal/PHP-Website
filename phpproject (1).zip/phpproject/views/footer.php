    <!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
    <script src="<?php echo TEMPLATEWEBPATH; ?>js/jquery-2.1.1.min.js"></script>		
    <!-- Include all compiled plugins (below), or include individual files as needed -->
    <script src="<?php echo TEMPLATEWEBPATH; ?>js/bootstrap.min.js"></script>	
	<script src="<?php echo TEMPLATEWEBPATH; ?>js/parallax.min.js"></script>
	<script src="<?php echo TEMPLATEWEBPATH; ?>js/wow.min.js"></script>
	<script src="<?php echo TEMPLATEWEBPATH; ?>js/jquery.easing.min.js"></script>
	<script type="text/javascript" src="<?php echo TEMPLATEWEBPATH; ?>js/fliplightbox.min.js"></script>
	<script src="<?php echo TEMPLATEWEBPATH; ?>js/functions.js"></script>
	<script>
	wow = new WOW(
	 {
	
		}	) 
		.init();
	</script>	
  </body>
</html>