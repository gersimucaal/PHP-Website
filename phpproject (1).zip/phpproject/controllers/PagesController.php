<?php

// Include Category Model
include_once '../models/Model.php';

// Index Action
function indexAction(){
	
	// Page General Data
	
	$PageName = isset($_GET['page']
	
	$PageName = 'index';
	$PlatPageOptions = GetPageContent ($PageName);
	$PageMetaD = $PlatPageOptions['page_meta_d'];
	$PageMetak = $PlatPageOptions['page_meta_k'];
	$PageTitle = $PlatPageOptions['page_title'];
	$PageName = $PlatPageOptions['Page_name'];
	
	
	
	//General Function
	$PlatLogo = GetLogo();
	$LogoType = $PlatLogo['logo_type'];
	$LogoLink = $PlatLogo['logo_link'];
	$LogoImage = $PlatLogo['logo_img_path'];
	$LogoText = $PlatLogo['logo_text'];
	$LogoUrl = $PlatLogo['logo_url'];
	
	$PlatTopMenus = GetParentsMenu();
	
	//Load Template
	include_once TEMPLATEPREFIX . 'header' . TEAMPLATEPOSFIX;
	include_once TEMPLATEPREFIX . 'content' . TEAMPLATEPOSFIX;
	include_once TEMPLATEPREFIX . 'footer' . TEAMPLATEPOSFIX;
	
}

?>