<?php

// Get Page Content
function GetPageContent($PageName) {
	global $db;
	$SqlStmt = $db->prepare("SELECT * FROM p149pm_page_options WHERE page_name=:PageName");
	$SqlStmt->bindValue(':PageName',$PageName, PDO::PARAM_STR);
	try{ $SqlStmt->execute(); } catch (PDOException $e) { die(); }
	$row = $SqlStmt->fetch(PDO::FETCH_ASSOC);
	return $row;
}

// Get Logo

function GetLogo() {
	global $db;
	$SqlStmt = $db->prepare("SELECT * FROM p149pm_logo_options");
	try{ $SqlStmt->execute(); } catch (PDOException $e) { die(); }
	$row = $SqlStmt->fetch(PDO::FETCH_ASSOC);
	if ($SqlStmt->rowCount() > 0) { return $row; }
	}
		
// Get Parent Menu

function GetParentsMenu() {
	global $db ;
	$SqlStmt = $db->prepare("SELECT * FROM p149pm_menu_options WHERE menu_parent_id=:MPId ORDER BY menu_order");
	$SqlStmt->bindValue(':MPId',0, PDO::PARAM_INT);
	try{ $SqlStmt->execute(); } catch (PDOExecption $e) { die(); }
	while($row = $SqlStmt->fetch(PDO::FETCH_ASSOC)) { $row['children'] = GetParentsSubMenu($row['menu_id']); $smartRs[] = $row; }
	if ($SqlStmt->rowCount() > 0) {return $smartRs; }
}

// Get Parents Sub Menu

function GetParentsSubMenu($MenuId) {
	global $db;
	$SqlStmt = $db->prepare("SELECT * FROM p149pm_menu_options WHERE menu_parent_id=MenuId ORDER BY menu_order");
	$SqlStmt->bindValue(':MenuId',$MenuId, PDO::PARAM_INT);
	try{ $SqlStmt->execute(); } catch (PDOException $e) { die(); }
	while($row = $SqlStmt->fetch(PDO::FETCH_ASSOC)) { $smartRs[] = $row; }
	if ($SqlStmt->rowCount() > 0) {return $smartRs; }
}

?>